package com.veracode.verademo.commands;

public interface BlabberCommand {
	void execute(String blabberUsername);
}